#include <iostream>
#include <fstream>
#include <map>
#include <string>
using namespace std;

// Room structure definition
struct Room {
    string type;
    int price;
    int booked;
    int total;
};

// Hotel class that manages room bookings
class Hotel {
private:
    map<string, Room> rooms;  // Map to store room types

public:
    // Constructor to initialize rooms
    Hotel() {
        rooms["Standard"] = {"Standard", 600, 0, 12};
        rooms["Luxury"] = {"Luxury", 1000, 0, 8};
        rooms["Presidential"] = {"Presidential", 5000, 0, 5};
        rooms["Penthouse"] = {"Penthouse", 9500, 0, 5};
    }

    // Function to check if the room type is available
    bool isValidRoomType(const string& roomType) {
        return rooms.find(roomType) != rooms.end();
    }

    // Function to display room availability
    void viewRooms() {
        int totalRoomsLeft = 0;

        for (map<string, Room>::iterator i = rooms.begin(); i != rooms.end(); ++i) {
            if (i->second.booked < i->second.total) {
                cout << "\n" << i->second.type << " Rooms left: "
                     << i->second.total - i->second.booked << endl;
                totalRoomsLeft += (i->second.total - i->second.booked);
            } else {
                cout << "\nNo more " << i->second.type << " rooms available.\n";
            }
        }
        cout << "Total rooms left: " << totalRoomsLeft << endl;
    }

    // Function to calculate total income from bookings
    double calculateTotalIncome() {
        double totalIncome = 0;

        cout << "\nDisplay total rooms booked and income made:" << endl;
        for (map<string, Room>::iterator i = rooms.begin(); i != rooms.end(); ++i) {
            totalIncome += i->second.booked * i->second.price;
            cout << i->second.type << " Rooms (" << i->second.price
                 << " per room): " << i->second.booked << " booked, Income: R"
                 << i->second.booked * i->second.price << endl;
        }
        cout << "Total expected income for the day: R" << totalIncome << endl;
        return totalIncome;
    }

    // Function to add room bookings
    void addRoomBooking(const string& roomType) {
        if (isValidRoomType(roomType)) {
            int days;
            bool validDays = false;

            while (!validDays) {
                cout << "Enter number of days (1-30): ";
                cin >> days;

                if (days <= 0 || days > 30) {
                    cout << "Invalid number of days. Please enter a number between 1 and 30.\n";
                } else {
                    validDays = true;
                }
            }

            if (rooms[roomType].booked < rooms[roomType].total) {
                rooms[roomType].booked += 1;
                cout << "Room booked successfully for " << days << " days.\n";
            } else {
                cout << "The room type is fully booked. Please try another room or date.\n";
            }
        } else {
            cout << "Room type not found. Please enter a valid room type.\n";
        }
    }

    // Function to change the room type for booking
    void updateRoomBooking(const string& currentRoomType, const string& newRoomType) {
        if (isValidRoomType(currentRoomType) && rooms[currentRoomType].booked > 0) {
            if (isValidRoomType(newRoomType) && rooms[newRoomType].booked < rooms[newRoomType].total) {
                rooms[currentRoomType].booked -= 1;
                rooms[newRoomType].booked += 1;
                cout << "Booking changed successfully from " << currentRoomType << " to " << newRoomType << ".\n";
            } else {
                cout << "The new room type is either unavailable or fully booked.\n";
            }
        } else {
            cout << "Current room type not found or no bookings available to update.\n";
        }
    }

    // Function to delete room bookings
    void deleteRoomBooking(const string& roomType) {
        if (isValidRoomType(roomType)) {
            rooms[roomType].booked = 0;
            cout << "Room bookings for " << roomType << " deleted.\n";
        } else {
            cout << "Room type not found. Please enter a valid room type.\n";
        }
    }
};

// Function to authenticate employee and manage roles
bool authenticateEmployee(const string& workID, const string& password, Hotel& hotel, int& managerCount, int& receptionistCount, bool& managerLoggedIn) {
    ifstream file("employees.txt");
    if (!file) {
        cerr << "Cannot open employees file.\n";
        return false;
    }

    string line, id, pass, name, role;
    bool found = false;

    while (getline(file, line)) {
        if (line.find("workID:") != string::npos) {
            id = line.substr(line.find(":") + 2);
            getline(file, line); // Read the password line
            if (line.find("Password:") != string::npos) {
                pass = line.substr(line.find(":") + 2);
            } else {
                cerr << "Incorrect password guideline.\n";
                continue;
            }

            getline(file, line); // Read the name line
            if (line.find("Name:") != string::npos) {
                name = line.substr(line.find(":") + 2);
            } else {
                cerr << "Incorrect name guideline.\n";
                continue;
            }

            getline(file, line); // Read the role line
            if (line.find("Role:") != string::npos) {
                role = line.substr(line.find(":") + 2);
            } else {
                cerr << "Incorrect role guideline.\n";
                continue;
            }

            if (id == workID && pass == password) {
                found = true;
                cout << "Welcome to Opulence Hotel, " << name << ", your role is " << role << "." << endl;

                if (role == "Manager") {
                    managerCount++;
                    managerLoggedIn = true;  // Set managerLoggedIn to true
                    cout << "Manager logged in.\n";
                } else if (role == "Receptionist") {
                    receptionistCount++;
                    int option;
                    bool logout = false;

                    while (!logout) {
                        cout << "1. Add Room Bookings\n"
                             << "2. Update Room Bookings\n"
                             << "3. Delete Room Bookings\n"
                             << "4. View Rooms Booked\n"
                             << "5. Calculate Total Income\n"
                             << "6. Log Out\n"
                             << "Select an option: ";
                        cin >> option;

                        switch (option) {
                            case 1: {
                                string roomType;
                                cout << "Enter room type: ";
                                cin >> roomType;
                                hotel.addRoomBooking(roomType);
                                break;
                            }
                            case 2: {
                                string currentRoomType, newRoomType;
                                cout << "Enter current room type: ";
                                cin >> currentRoomType;
                                cout << "Enter new room type: ";
                                cin >> newRoomType;
                                hotel.updateRoomBooking(currentRoomType, newRoomType);
                                break;
                            }
                            case 3: {
                                string roomType;
                                cout << "Enter room type to delete bookings: ";
                                cin >> roomType;
                                hotel.deleteRoomBooking(roomType);
                                break;
                            }
                            case 4:
                                hotel.viewRooms();
                                break;
                            case 5: {
                                if (!managerLoggedIn) {
                                    cout << "Gross cannot be calculated because manager is absent.\n";
                                } else {
                                    hotel.calculateTotalIncome();
                                }
                                break;
                            }
                            case 6:
                                logout = true;
                                cout << "Logging out...\n";
                                break;
                            default:
                                cout << "Invalid option. Please try again.\n";
                        }
                    }
                }
                break; // Break the outer loop on successful login
            }
        }
    }

    if (!found) {
        cout << "Invalid Work ID or Password. Please try again.\n";
    }

    return found; // Return true if employee was found, false otherwise
}

int main() {
    Hotel hotel;
    int managerCount = 0;
    int receptionistCount = 0;
    bool enterAnotherEmployee = true;
    bool managerLoggedIn = false;

    while (enterAnotherEmployee) {
        string workID, password;
        int attempts = 0;
        const int maxAttempts = 3;

        while (attempts < maxAttempts) {
            cout << "Please enter your Work ID: ";
            cin >> workID;
            cout << "Please enter your password: ";
            cin >> password;

            bool authenticated = authenticateEmployee(workID, password, hotel, managerCount, receptionistCount, managerLoggedIn);

            if (authenticated) {
                break; // Exit the input loop if authenticated
            } else {
                attempts++;
                if (attempts < maxAttempts) {
                    cout << "Invalid credentials. Please try again. Attempts remaining: " << (maxAttempts - attempts) << endl;
                } else {
                    cout << "Maximum attempts reached. Exiting...\n";
                }
            }
        }

        char choice;
        cout << "Do you want to enter another employee? (Y/N): ";
        cin >> choice;
        enterAnotherEmployee = (choice == 'Y' || choice == 'y');
    }
    return 0;
}
